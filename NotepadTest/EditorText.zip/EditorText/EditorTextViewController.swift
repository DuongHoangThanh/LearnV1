////
////  EditorTextViewController.swift
////  NotepadTest
////
////  Created by Thạnh Dương Hoàng on 6/5/25.
////
//
//import UIKit
//
//class AddNoteViewController2: UIViewController {
//    let editor = RichEditorView2()
//    let toolbar = EditorToolbar()
//    private var styleSheetView = UIView()
//    private var imageURIs: [String] = []
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        view.backgroundColor = .white
//        setupEditor()
//        setupToolbar()
//        setupKeyboardObservers()
//        addPasteObserver()
//    }
//    
//    private func setupEditor() {
//        view.addSubview(editor)
//        editor.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            editor.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
//            editor.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            editor.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            editor.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//    }
//    
//    private func setupToolbar() {
//        view.addSubview(toolbar)
//        toolbar.translatesAutoresizingMaskIntoConstraints = false
//        setupButtonActions()
//        NSLayoutConstraint.activate([
//            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            toolbar.heightAnchor.constraint(equalToConstant: 44),
//            toolbar.bottomAnchor.constraint(equalTo: view.bottomAnchor) // sẽ update khi bàn phím hiển thị
//        ])
//    }
//    
//    private func setupButtonActions() {
//        toolbar.scan.addTarget(self, action: #selector(getNoteText), for: .touchUpInside)
//        toolbar.style.addTarget(self, action: #selector(showStyleSheet), for: .touchUpInside)
//        toolbar.checkboxButton.addTarget(self, action: #selector(applyCheckbox), for: .touchUpInside)
//        toolbar.setHtml.addTarget(self, action: #selector(setHTML), for: .touchUpInside)
//    }
//    
//    private func setupStyleSheetView() {
//        styleSheetView.backgroundColor = .systemGroupedBackground
//        styleSheetView.translatesAutoresizingMaskIntoConstraints = false
//        styleSheetView.isHidden = true
//        view.addSubview(styleSheetView)
//        
//        NSLayoutConstraint.activate([
//            styleSheetView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),
//            styleSheetView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            styleSheetView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            styleSheetView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        let heading1 = makeToolbarButton(title: "I", action: #selector(applyItalic))
//        let bold = makeToolbarButton(title: "B", action: #selector(applyBold))
//        let red = makeToolbarButton(title: "U", action: #selector(applyUnderline))
//        
//        let stack = UIStackView(arrangedSubviews: [heading1, bold, red])
//        stack.axis = .horizontal
//        stack.distribution = .fillEqually
//        stack.translatesAutoresizingMaskIntoConstraints = false
//        styleSheetView.addSubview(stack)
//        
//        NSLayoutConstraint.activate([
//            stack.topAnchor.constraint(equalTo: styleSheetView.topAnchor, constant: 10),
//            stack.leadingAnchor.constraint(equalTo: styleSheetView.leadingAnchor),
//            stack.trailingAnchor.constraint(equalTo: styleSheetView.trailingAnchor),
//            stack.heightAnchor.constraint(equalToConstant: 50)
//        ])
//    }
//    
//    private func makeToolbarButton(title: String, action: Selector) -> UIButton {
//        let button = UIButton(type: .system)
//        button.setTitle(title, for: .normal)
//        button.addTarget(self, action: action, for: .touchUpInside)
//        return button
//    }
//    
//    @objc func showStyleSheet() {
//        styleSheetView.isHidden.toggle()
//    }
//    
//    @objc func applyBold() { editor.setBold() }
//    @objc func applyItalic() { editor.setItalic() }
//    @objc func applyUnderline() { editor.setUnderline() }
//    @objc func applyCheckbox() { editor.insertCheckbox() }
//    
//    private func setupKeyboardObservers() {
//        NotificationCenter.default.addObserver(self,
//                                               selector: #selector(keyboardWillChange),
//                                               name: UIResponder.keyboardWillChangeFrameNotification,
//                                               object: nil)
//    }
//    
//    @objc private func keyboardWillChange(_ notification: Notification) {
//        guard let userInfo = notification.userInfo,
//              let frameEnd = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
//              let duration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval else { return }
//        
//        let isKeyboardShowing = frameEnd.origin.y < UIScreen.main.bounds.height
//        let height = isKeyboardShowing ? frameEnd.height : 0
//        
//        UIView.animate(withDuration: duration) {
//            self.toolbar.transform = CGAffineTransform(translationX: 0, y: -height)
//        }
//    }
//    
//    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
//        if action == #selector(paste(_:)) {
//            print("Yes")
//            return UIPasteboard.general.hasImages // Cho phép nếu clipboard có ảnh
//        }
//        //        print("Confirm action: no no")
//        return super.canPerformAction(action, withSender: sender)
//    }
//    
//    @objc func getNoteText() {
//        editor.getHTML { string in
//            print(string!)
//            
//            UserDefaults.standard.set(string, forKey: "note")
//            print(UserDefaults.standard.string(forKey: "note") ?? "No HTMl saved")
//        }
//    }
//    
//    @objc func setHTML() {
//        print(UserDefaults.standard.string(forKey: "note") ?? "No HTMl saved")
//        editor.setHTML(content: UserDefaults.standard.string(forKey: "note") ?? "<h1>No HTML hehe</h1>")
////        editor.setHTML(content: "<h1>No HTML</h1>")
//        
//    }
//    
//    override func paste(_ sender: Any?) {
//        if let image = UIPasteboard.general.image {
//            //            insertImage(image)
//            print("Yes image vc")
//        } else {
//            super.paste(sender)
//            print("No image vc")
//        }
//    }
//    
//    func addPasteObserver() {
//        let pasteGesture = UITapGestureRecognizer(target: self, action: #selector(handlePaste))
//        pasteGesture.numberOfTapsRequired = 2
//        editor.addGestureRecognizer(pasteGesture)
//    }
//    
//    @objc func handlePaste() {
//        if let image = UIPasteboard.general.image {
//            if let fileURL = saveImageToDocuments(image: image) {
//                imageURIs.append(fileURL.path)
//                insertImageInEditor(imageURL: fileURL)
//            }
//        } else {
//            print("Không có ảnh trong clipboard.")
//        }
//    }
//    
//    func saveImageToDocuments(image: UIImage) -> URL? {
//        guard let data = image.jpegData(compressionQuality: 0.8) else { return nil }
//        
//        let fileName = "image_\(UUID().uuidString.prefix(6)).jpg"
//        
//        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
//            .appendingPathComponent(fileName)
//        print(fileName)
//        print(fileURL)
//        do {
//            try data.write(to: fileURL)
//            return fileURL
//        } catch {
//            print("Lỗi lưu ảnh: \(error)")
//            return nil
//        }
//    }
//    
//    func insertImageInEditor(imageURL: URL) {
//        // Đường dẫn dạng file:///... cần encode trước khi truyền vào JS
//        let encodedURL = imageURL.absoluteString
//        editor.insertImage(url: encodedURL)
//    }
//}
