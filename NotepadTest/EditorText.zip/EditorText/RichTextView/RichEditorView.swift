////
////  RichEditorView.swift
////  NotepadTest
////
////  Created by Thạnh Dương Hoàng on 14/5/25.
////
//
//import Foundation
//import WebKit
//
//class RichEditorView2: UIView {
//    private let webView = WKWebView()
//    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        setup()
//    }
//    
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        setup()
//    }
//    
//    private func setup() {
//        addSubview(webView)
//        webView.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            webView.topAnchor.constraint(equalTo: topAnchor),
//            webView.bottomAnchor.constraint(equalTo: bottomAnchor),
//            webView.leadingAnchor.constraint(equalTo: leadingAnchor),
//            webView.trailingAnchor.constraint(equalTo: trailingAnchor)
//        ])
//        loadEditor()
//    }
//    
//    private func loadEditor() {
//        if let path = Bundle.main.path(forResource: "rich_editor", ofType: "html") {
//            let url = URL(fileURLWithPath: path)
//            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
////            if let html = UserDefaults.standard.string(forKey: "note") {
////                
////                let js = "document.getElementById('editor').innerHTML = `\(html)`;"
////                webView.evaluateJavaScript(js, completionHandler: nil)
////            }
//            print("Load html success!")
//        } else {
//            print("Load html fail!")
//        }
//    }
//    
//    func setBold() {
//        webView.evaluateJavaScript("document.execCommand('bold')", completionHandler: nil)
//    }
//    
//    func setItalic() {
//        webView.evaluateJavaScript("document.execCommand('italic')", completionHandler: nil)
//    }
//    
//    func setUnderline() {
//        webView.evaluateJavaScript("document.execCommand('underline')", completionHandler: nil)
//    }
//    
//    func insertCheckbox() {
//        webView.evaluateJavaScript("document.execCommand('insertHTML', false, '<input style=\"width: 20px; height: 20px;\" type=\"checkbox\">')", completionHandler: nil)
//    }
//    
//    func getHTML(completion: @escaping (String?) -> Void) {
//        webView.evaluateJavaScript("document.getElementById('editor').innerHTML") { result, error in
//            completion(result as? String)
//        }
//    }
//    
//    func setHTML(content: String) {
//        let js = "document.getElementById('editor').innerHTML = `\(content)`;"
//        webView.evaluateJavaScript(js, completionHandler: nil)
//    }
//    
//    func insertImage(url: String) {
//        // how to fit auto size image to adapt screen size, example: image size 50x50 => show on screen 50x50 but image size 100x100 => show on screen 100x100 but image size larger than screen => show on screen full width or height
//        webView.evaluateJavaScript("document.execCommand('insertHTML', false, '<img src=\"\(url)\" style=\"max-width: 100%; height: auto;\">')", completionHandler: nil)
//    }
//    
////    override func paste(_ sender: Any?) {
////        if let image = UIPasteboard.general.image {
////            //            insertImage(image)
////            print("Yes image")
////        } else {
////            super.paste(sender)
////            print("No image")
////        }
////    }
//}
//
