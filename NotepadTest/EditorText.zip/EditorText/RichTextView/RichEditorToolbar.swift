//
//  RichEditorToolbar.swift
//  NotepadTest
//
//  Created by Thạnh Dương Hoàng on 14/5/25.
//

import Foundation
import UIKit

class EditorToolbar: UIView {
    let scan  = UIButton(type: .system)
    let style = UIButton(type: .system)
    let checkboxButton = UIButton(type: .system)
    let setHtml = UIButton(type: .system)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private func setup() {
        backgroundColor = .secondarySystemBackground
        let stack = UIStackView(arrangedSubviews: [scan, style, checkboxButton, setHtml])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.spacing = 8
        addSubview(stack)
        
        scan.setTitle("Image", for: .normal)
        style.setTitle("Style", for: .normal)
        checkboxButton.setTitle("☑︎", for: .normal)
        setHtml.setTitle("SetHTML", for: .normal)
        
        stack.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -4),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
        ])
    }
}
